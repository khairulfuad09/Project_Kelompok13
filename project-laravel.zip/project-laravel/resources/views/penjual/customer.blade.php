@extends('partials.main')
@section('container')
    <h1>customer</h1>
@endsection
