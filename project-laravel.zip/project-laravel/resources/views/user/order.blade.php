@extends('partials.main')
@section('container')
    <h1>Order</h1>
@endsection