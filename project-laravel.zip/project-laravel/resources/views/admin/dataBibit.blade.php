@extends('partials.main')
@section('container')
    {{-- <h1>Product</h1> --}}
@endsection