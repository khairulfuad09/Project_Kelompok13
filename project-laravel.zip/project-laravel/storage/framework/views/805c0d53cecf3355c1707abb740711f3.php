
<?php $__env->startSection('container'); ?>
    <h1>Tambah User</h1>
    <form action="/user/<?php echo e($user->id); ?>" method="post" class="from-tUser">
        <?php echo method_field('put'); ?>
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" id="username" placeholder="username" name="username" value="<?php echo e(old('username', $user->username)); ?>">
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" placeholder="name@example.com" name="email" value="<?php echo e(old('email', $user->email)); ?>">
        </div>
        <div class="mb-3">
            <label for="alamat" class="form-label">Alamat</label>
            <input type="text" class="form-control" id="alamat" placeholder="alamat" name="alamat" value="<?php echo e(old('alamat', $user->alamat)); ?>">
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" placeholder="" name="password">
        </div>
        <input type="hidden" name="id_status" value="usr">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><a
            href="/user">Close</a></button>
    <button type="submit" class="btn btn-blue">Update data</button>
</div>

    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Aplications_Laravel\project-laravel\resources\views/admin/updateUser.blade.php ENDPATH**/ ?>