
<?php $__env->startSection('container'); ?>
    <h1>Product</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Aplications_Laravel\project-laravel\resources\views/Product.blade.php ENDPATH**/ ?>